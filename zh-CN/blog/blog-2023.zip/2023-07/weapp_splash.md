---
lastUpdated: true
commentabled: true
recommended: false
title: 如何为小程序添加一个启动页
description: 如何为小程序添加一个启动页
poster: /logos/logo_wechat.png
date: 2023-07
---

# 如何为小程序添加一个启动页 #

## 背景 ##

最近在做小程序开发，遇到如何全局进行登录状态校验，又如何让用户无感的完成了登录。

加入启动页面，增强体验感。

## WXML ##



## TypeScript ##



## LESS ##


